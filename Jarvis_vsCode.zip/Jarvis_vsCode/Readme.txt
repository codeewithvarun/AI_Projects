                                            ------ Descripation ------

- This AI name is Jarvis.
- Jarvis developed in Python programming language.
- Jarvis main purpose is to assist your computer on your given vioce commands.
- Jarvis working like - Google assistant, Alexa, Siri.

                                            -------- Functions --------

- Jarvis talk to user with Male voice.
- Talk greeting to user.
- Jarvis try to listen and understand user voice command.
- When user Run program Jarvis gose on Listening mode. (Listening.....)
- Three most usable commands - "Wake Up" for active.
                               "Go to sleeeping mode" for sleeeping mode.
                               "Go to sleep" for deactive.
- For use of Jarvis user need to give "WAKE UP" command in his voice.
- Jarvis talk to user as human.
- Jarvis open any app from user Laptop or Computer and Websites from browser.
- Jarvis using browser for searching. (Google search, YouTube, Wikipedia)
- If user wants to open any Websites (.com , .co.in , .org) Make sure first open your any browser (Recommended browser - Chrome)
- Jarvis gives user Temperature , Weather , Time , Date.
- 


            ------ App List ------

    AppNames                      AppValue

commandprompt                   : cmd
discord                         : discord
paint                           : paint
word                            : winword
excel                           : excel
chrome                          : chrome
vscode                          : code
powerpoint                      : powerpnt
wordpad                         : wordpad
notepad                         : notepad 
calculator                      : calc
photoshop                       : photoshop
spotify                         : spotify
vlc                             : vlc

    