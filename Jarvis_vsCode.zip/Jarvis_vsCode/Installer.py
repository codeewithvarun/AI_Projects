import pip
pip.main(['install','bs4'])